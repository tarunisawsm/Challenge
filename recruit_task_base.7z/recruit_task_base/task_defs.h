#ifndef TASK_DEFS_H

#define TASK_DEFS_H


#define JSON_DATA_URL "https://dl.dropboxusercontent.com/s/wtaxey4zk465f5u/drivers.json?dl=1"


#define DRIVERS_DATABASE_FILE "drivers.sqlite"

#define DRIVER_TABLE_NAME "drivers"


#define TABLE_CREATE "CREATE TABLE " DRIVER_TABLE_NAME " (id INTEGER PRIMARY KEY, first_name VARCHAR, last_name VARCHAR, key VARCHAR)"

//Structure to store the records from JSON file
typedef struct
{
	int id;
	const char *firstName;
	const char *lastName;
	int key;
}DRIVERS;

//Function Declarations
void parseJsonData( char *fileName );
void createAndDisplayData( int len, DRIVERS *driverList );


#endif